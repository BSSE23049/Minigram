const express = require('express');
const router = express.Router();
const { 
  createPost, 
  getPosts, 
  getUserPosts, 
  getPost, 
  likePost, 
  unlikePost, 
  addComment, 
  deletePost 
} = require('../controllers/postController');
const { protect } = require('../middlewares/auth');

router.post('/', protect, createPost);
router.get('/', protect, getPosts);
router.get('/user/:userId', protect, getUserPosts);
router.get('/:id', protect, getPost);
router.post('/:id/like', protect, likePost);
router.delete('/:id/like', protect, unlikePost);
router.post('/:id/comments', protect, addComment);
router.delete('/:id', protect, deletePost);

module.exports = router;