const express = require('express');
const router = express.Router();
const {
  getUserProfile,
  updateUserProfile,
  followUser,
  unfollowUser,
  getUserFollowers,
  getUserFollowings,
  searchUsers,
  getSuggestedUsers
} = require('../controllers/userController');
const { protect } = require('../middlewares/auth');

router.get('/profile/:username', getUserProfile);
router.put('/profile', protect, updateUserProfile);
router.post('/follow/:id', protect, followUser);
router.delete('/follow/:id', protect, unfollowUser);
router.get('/:id/followers', protect, getUserFollowers);
router.get('/:id/following', protect, getUserFollowings);
router.get('/search', protect, searchUsers);
router.get('/suggested', protect, getSuggestedUsers);

module.exports = router;