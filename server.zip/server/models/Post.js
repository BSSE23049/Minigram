const { DataTypes } = require('sequelize');
const db = require('../config/database');
const User = require('./User');

const Post = db.define('post', {
  caption: {
    type: DataTypes.TEXT
  },
  image_url: {
    type: DataTypes.STRING,
    allowNull: false
  },
  likes_count: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  },
  comments_count: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  }
}, {
  timestamps: true
});

Post.belongsTo(User, { foreignKey: 'user_id' });
User.hasMany(Post, { foreignKey: 'user_id' });

module.exports = Post;