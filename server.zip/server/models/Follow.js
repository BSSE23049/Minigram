const { DataTypes } = require('sequelize');
const db = require('../config/database');
const User = require('./User');

const Follow = db.define('follow', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  }
}, {
  timestamps: true
});

Follow.belongsTo(User, { as: 'follower', foreignKey: 'follower_id' });
Follow.belongsTo(User, { as: 'following', foreignKey: 'following_id' });

module.exports = Follow;