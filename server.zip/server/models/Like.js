const { DataTypes } = require('sequelize');
const db = require('../config/database');
const User = require('./User');
const Post = require('./Post');

const Like = db.define('like', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  }
}, {
  timestamps: true
});

Like.belongsTo(User, { foreignKey: 'user_id' });
Like.belongsTo(Post, { foreignKey: 'post_id' });
User.hasMany(Like, { foreignKey: 'user_id' });
Post.hasMany(Like, { foreignKey: 'post_id' });

module.exports = Like;