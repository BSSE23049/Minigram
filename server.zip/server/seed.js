// Create a file called seed.js
const bcrypt = require('bcryptjs');
const User = require('./models/User');
const db = require('./config/database');

const seedDatabase = async () => {
  try {
    await db.sync({ force: true });
    
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash('password123', salt);
    
    await User.create({
      username: 'test_user',
      email: 'test@example.com',
      password: hashedPassword,
      bio: 'This is a test account'
    });
    
    console.log('Database seeded successfully');
    process.exit(0);
  } catch (err) {
    console.error('Error seeding database:', err);
    process.exit(1);
  }
};

seedDatabase();