const Post = require('../models/Post');
const User = require('../models/User');
const Comment = require('../models/Comment');
const Like = require('../models/Like');
const { Op } = require('sequelize');

// Create new post
exports.createPost = async (req, res) => {
  try {
    const { caption } = req.body;
    
    // In a real app, you would handle file uploads here
    // For simplicity, we're assuming image_url is passed in the request
    const { image_url } = req.body;

    const post = await Post.create({
      caption,
      image_url,
      user_id: req.user.id
    });

    res.status(201).json(post);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

// Get all posts (feed)
exports.getPosts = async (req, res) => {
  try {
    const posts = await Post.findAll({
      include: [
        {
          model: User,
          attributes: ['id', 'username', 'profile_pic']
        }
      ],
      order: [['createdAt', 'DESC']],
      limit: 10
    });

    res.json(posts);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

// Get user posts
exports.getUserPosts = async (req, res) => {
  try {
    const posts = await Post.findAll({
      where: { user_id: req.params.userId },
      include: [
        {
          model: User,
          attributes: ['id', 'username', 'profile_pic']
        }
      ],
      order: [['createdAt', 'DESC']]
    });

    res.json(posts);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

// Get single post
exports.getPost = async (req, res) => {
  try {
    const post = await Post.findByPk(req.params.id, {
      include: [
        {
          model: User,
          attributes: ['id', 'username', 'profile_pic']
        },
        {
          model: Comment,
          include: [
            {
              model: User,
              attributes: ['id', 'username', 'profile_pic']
            }
          ],
          order: [['createdAt', 'DESC']]
        }
      ]
    });

    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    // Check if the current user liked this post
    const liked = await Like.findOne({
      where: {
        post_id: post.id,
        user_id: req.user.id
      }
    });

    res.json({
      ...post.toJSON(),
      liked: !!liked
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

// Like a post
exports.likePost = async (req, res) => {
  try {
    const post = await Post.findByPk(req.params.id);
    
    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    // Check if the user already liked the post
    const existingLike = await Like.findOne({
      where: {
        post_id: post.id,
        user_id: req.user.id
      }
    });

    if (existingLike) {
      return res.status(400).json({ error: 'Post already liked' });
    }

    // Create like
    await Like.create({
      post_id: post.id,
      user_id: req.user.id
    });

    // Update post likes count
    post.likes_count += 1;
    await post.save();

    res.json({ message: 'Post liked', likes_count: post.likes_count });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

// Unlike a post
exports.unlikePost = async (req, res) => {
  try {
    const post = await Post.findByPk(req.params.id);
    
    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    // Find and remove like
    const like = await Like.findOne({
      where: {
        post_id: post.id,
        user_id: req.user.id
      }
    });

    if (!like) {
      return res.status(400).json({ error: 'Post not liked yet' });
    }

    await like.destroy();

    // Update post likes count
    post.likes_count = Math.max(0, post.likes_count - 1);
    await post.save();

    res.json({ message: 'Post unliked', likes_count: post.likes_count });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

// Add comment to post
exports.addComment = async (req, res) => {
  try {
    const post = await Post.findByPk(req.params.id);
    
    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    const comment = await Comment.create({
      content: req.body.content,
      post_id: post.id,
      user_id: req.user.id
    });

    // Update post comments count
    post.comments_count += 1;
    await post.save();

    // Get comment with user details
    const commentWithUser = await Comment.findByPk(comment.id, {
      include: [
        {
          model: User,
          attributes: ['id', 'username', 'profile_pic']
        }
      ]
    });

    res.status(201).json(commentWithUser);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

// Delete post
exports.deletePost = async (req, res) => {
  try {
    const post = await Post.findByPk(req.params.id);
    
    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    // Check post ownership
    if (post.user_id !== req.user.id) {
      return res.status(401).json({ error: 'Not authorized' });
    }

    await post.destroy();
    
    res.json({ message: 'Post removed' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};