const User = require('../models/User');
const Follow = require('../models/Follow');
const { Op } = require('sequelize');

// Get user profile
exports.getUserProfile = async (req, res) => {
  try {
    const user = await User.findOne({
      where: { username: req.params.username },
      attributes: { exclude: ['password'] }
    });

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Get follower and following counts
    const followerCount = await Follow.count({
      where: { following_id: user.id }
    });

    const followingCount = await Follow.count({
      where: { follower_id: user.id }
    });

    // Check if the current user follows this user
    const isFollowing = req.user ? await Follow.findOne({
      where: {
        follower_id: req.user.id,
        following_id: user.id
      }
    }) : null;

    res.json({
      ...user.toJSON(),
      follower_count: followerCount,
      following_count: followingCount,
      is_following: !!isFollowing
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

// Update user profile
exports.updateUserProfile = async (req, res) => {
  try {
    const user = await User.findByPk(req.user.id);
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const { username, bio, profile_pic } = req.body;

    // Check if username is taken
    if (username && username !== user.username) {
      const usernameExists = await User.findOne({ where: { username } });
      if (usernameExists) {
        return res.status(400).json({ error: 'Username already taken' });
      }
    }

    // Update fields
    if (username) user.username = username;
    if (bio !== undefined) user.bio = bio;
    if (profile_pic) user.profile_pic = profile_pic;

    await user.save();

    res.json({
      id: user.id,
      username: user.username,
      email: user.email,
      bio: user.bio,
      profile_pic: user.profile_pic,
      is_verified: user.is_verified
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

// Follow a user
exports.followUser = async (req, res) => {
  try {
    if (req.params.id == req.user.id) {
      return res.status(400).json({ error: 'You cannot follow yourself' });
    }

    const userToFollow = await User.findByPk(req.params.id);
    
    if (!userToFollow) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Check if already following
    const alreadyFollowing = await Follow.findOne({
      where: {
        follower_id: req.user.id,
        following_id: userToFollow.id
      }
    });

    if (alreadyFollowing) {
      return res.status(400).json({ error: 'Already following this user' });
    }

    await Follow.create({
      follower_id: req.user.id,
      following_id: userToFollow.id
    });

    res.json({ message: 'User followed successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

// Unfollow a user
exports.unfollowUser = async (req, res) => {
  try {
    if (req.params.id == req.user.id) {
      return res.status(400).json({ error: 'You cannot unfollow yourself' });
    }

    const userToUnfollow = await User.findByPk(req.params.id);
    
    if (!userToUnfollow) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Find and remove follow relationship
    const follow = await Follow.findOne({
      where: {
        follower_id: req.user.id,
        following_id: userToUnfollow.id
      }
    });

    if (!follow) {
      return res.status(400).json({ error: 'Not following this user' });
    }

    await follow.destroy();

    res.json({ message: 'User unfollowed successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

// Get user followers
exports.getUserFollowers = async (req, res) => {
  try {
    const follows = await Follow.findAll({
      where: { following_id: req.params.id },
      include: [
        {
          model: User,
          as: 'follower',
          attributes: ['id', 'username', 'profile_pic', 'is_verified']
        }
      ]
    });

    const followers = follows.map(follow => follow.follower);
    
    res.json(followers);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

// Get user followings
exports.getUserFollowings = async (req, res) => {
  try {
    const follows = await Follow.findAll({
      where: { follower_id: req.params.id },
      include: [
        {
          model: User,
          as: 'following',
          attributes: ['id', 'username', 'profile_pic', 'is_verified']
        }
      ]
    });

    const followings = follows.map(follow => follow.following);
    
    res.json(followings);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

// Search users
exports.searchUsers = async (req, res) => {
  try {
    const query = req.query.q;
    
    if (!query) {
      return res.status(400).json({ error: 'Query parameter is required' });
    }

    const users = await User.findAll({
      where: {
        username: {
          [Op.like]: `%${query}%`
        }
      },
      attributes: ['id', 'username', 'profile_pic', 'is_verified'],
      limit: 20
    });

    res.json(users);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

// Get suggested users to follow
exports.getSuggestedUsers = async (req, res) => {
  try {
    // Find users that the current user doesn't follow
    const following = await Follow.findAll({
      where: { follower_id: req.user.id },
      attributes: ['following_id']
    });
    
    const followingIds = following.map(f => f.following_id);
    followingIds.push(req.user.id); // Add current user ID to exclusion list
    
    const suggestedUsers = await User.findAll({
      where: {
        id: {
          [Op.notIn]: followingIds
        }
      },
      attributes: ['id', 'username', 'profile_pic', 'is_verified'],
      limit: 5,
      order: [['createdAt', 'DESC']]
    });
    
    res.json(suggestedUsers);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};